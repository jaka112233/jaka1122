#include <list>
#include <vector>
#include <string.h>
#include <pthread.h>
#include <thread>
#include <cstring>
#include <jni.h>
#include <unistd.h>
#include <fstream>
#include <iostream>
#include <dlfcn.h>
#include "Includes/Logger.h"
#include "Includes/obfuscate.h"
#include "Includes/Utils.h"
#include "KittyMemory/MemoryPatch.h"
#include "Menu/Setup.h"
#include "Includes/Macros.h"

#include "IL2CppSDKGenerator/BasicStructs/Call_BasicStructs.h"
#include "IL2CppSDKGenerator/IL2Cpp/Call_IL2Cpp.h"

#define m_IL2CPPLIB OBFUSCATE("libil2cpp.so")
#define targetLibName OBFUSCATE("libil2cpp.so")

uintptr_t m_Il2Cpp;

void *instanceBtn;

struct My_Patches {
    MemoryPatch Nextjek ;
} jek;

float FloatValue = 1;
int Value = 1, SliderValue = 1;
int IsMinSpeed,isMaxSpedd,IsHightjump,IsHightjumpAir = 1;

bool isScore = false;
bool isCoin = false;
//bool isAddCoin = false;
bool isGodMode = false;
bool isGodMode1 = false;
bool isGodMode2 = false;
bool isGodMode3 = false;
bool isActivement = false;
bool isDCoin = false;
bool isBCoin = false;
bool isInstan = false;
bool gravitasi = false;
bool isMultiScore = false;
bool isAutoRevive = false;
bool isAutoRevive1 = false;
bool isAutoRevive2 = false;
bool isMultiJump = false;
bool isMultiJump1 = false;
bool isFreeBuy = false;
bool isFreeBuy1 = false;
bool isStopTrain = false;
bool isCameraF = false;
bool isCameraS = false;


/*
void (*AddCoin)(void *instance, int count);
void (*old_MoneyUpdate)(void *instance);
      void MoneyUpdate(void *instance){
        if (instance != NULL){
         if (isAddCoin){
          AddCoin(instance, 1000000); // value
          }
     }
     return old_MoneyUpdate(instance);
}
*/
int (*old_Coin)(void*instance);
int Coin(void*instance){
    if(instance != NULL){
        if(isCoin){
            
            return 99999999;
        }
    }
    return old_Coin(instance);
}

int (*old_Score)(void*instance);
int Score(void*instance){
    if(instance != NULL){
        if(isScore){
            
            return 99999999;
        }
    }
    return old_Score(instance);
}

int (*old_MultiScore)(void*instance);
int MultiScore(void*instance){
    if(instance != NULL){
        if(isMultiScore){
            
            return 2000000;
        }
    }
    return old_MultiScore(instance);
}

bool(*old_DCoin)(void*instance);
bool DCoin(void*instance){
    if(instance != NULL){
        if(isDCoin){
            
            return true;
        }
    }
    return old_DCoin(instance);
}

bool(*old_BCoin)(void*instance);
bool BCoin(void*instance){
    if(instance != NULL){
        if(isBCoin){
            
            return true;
        }
    }
    return old_BCoin(instance);
}

bool(*old_Activement)(void*instance);
bool Activement(void*instance){
    if(instance != NULL){
        if(isActivement){
            
            return true;
        }
    }
    return old_Activement(instance);
}

bool(*old_AutoRevive)(void*instance);
bool AutoRevive(void*instance){
    if(instance != NULL){
        if(isAutoRevive){
            
            return true;
        }
    }
    return old_AutoRevive(instance);
}

bool(*old_AutoRevive2)(void*instance);
bool AutoRevive2(void*instance){
    if(instance != NULL){
        if(isAutoRevive2){
            
            return false;
        }
    }
    return old_AutoRevive2(instance);
}

int (*old_AutoRevive1)(void*instance);
int AutoRevive1(void*instance){
    if(instance != NULL){
        if(isAutoRevive1){
            
            return 0;
        }
    }
    return old_AutoRevive1(instance);
}

bool(*old_MultiJump)(void*instance);
bool MultiJump(void*instance){
    if(instance != NULL){
        if(isMultiJump){
            
            return true;
        }
    }
    return old_MultiJump(instance);
}

bool(*old_MultiJump1)(void*instance);
bool MultiJump1(void*instance){
    if(instance != NULL){
        if(isMultiJump1){
            
            return true;
        }
    }
    return old_MultiJump1(instance);
}

bool(*old_GodMode)(void*instance);
bool GodMode(void*instance){
    if(instance != NULL){
        if(isGodMode){
            
            return false;
        }
    }
    return old_GodMode(instance);
}

bool(*old_GodMode1)(void*instance);
bool GodMode1(void*instance){
    if(instance != NULL){
        if(isGodMode1){
            
            return false;
        }
    }
    return old_GodMode1(instance);
}
bool(*old_GodMode2)(void*instance);
bool GodMode2(void*instance){
    if(instance != NULL){
        if(isGodMode2){
            
            return false;
        }
    }
    return old_GodMode2(instance);
}
bool(*old_GodMode3)(void*instance);
bool GodMode3(void*instance){
    if(instance != NULL){
        if(isGodMode3){
            
            return false;
        }
    }
    return old_GodMode3(instance);
}

bool(*old_FreeBuy)(void*instance);
bool FreeBuy(void*instance){
    if(instance != NULL){
        if(isFreeBuy){
            
            return false;
        }
    }
    return old_FreeBuy(instance);
}

bool(*old_FreeBuy1)(void*instance);
bool FreeBuy1(void*instance){
    if(instance != NULL){
        if(isFreeBuy1){
            
            return true;
        }
    }
    return old_FreeBuy1(instance);
}

float (*old_MinSpeed)(void *instance);
float getMinSpeed(void *instance) {
    if (instance != NULL && IsMinSpeed > 1) {
        return (float) IsMinSpeed;
    }
    return old_MinSpeed(instance);
}

float (*old_MaxSpeed)(void *instance);
float getMaxSpeed(void *instance) {
    if (instance != NULL && isMaxSpedd > 1) {
        return (float) isMaxSpedd;
    }
    return old_MaxSpeed(instance);
}

float (*old_jump)(void *instance);
float jump(void *instance) {
    if (instance != NULL && IsHightjump > 1) {
        return (float) IsHightjump;
    }
    return old_jump(instance);
}

float (*old_jump1)(void *instance);
float jump1(void *instance) {
    if (instance != NULL && IsHightjumpAir > 1) {
        return (float) IsHightjumpAir;
    }
    return old_jump1(instance);
}

float(*old_Instan)(void*instance);
float Instan(void*instance){
    if(instance != NULL){
        if(isInstan){
            
            return 0.000000001;
        }
    }
    return old_Instan(instance);
}

bool(*old_gravi)(void*instance);
bool gravi(void*instance){
    if(instance != NULL){
        if(gravitasi){
            
            return false;
        }
    }
    return old_gravi(instance);
}

bool(*old_CameraF)(void*instance);
bool CameraF(void*instance){
    if(instance != NULL){
        if(isCameraF){
            
            return true;
        }
    }
    return old_CameraF(instance);
}

bool(*old_CameraS)(void*instance);
bool CameraS(void*instance){
    if(instance != NULL){
        if(isCameraS){
            
            return true;
        }
    }
    return old_CameraS(instance);
}

bool(*old_StopTrain)(void*instance);
bool StopTrain(void*instance){
    if(instance != NULL){
        if(isStopTrain){
            
            return true;
        }
    }
    return old_StopTrain(instance);
}

void *hack_thread(void *) {
    LOGI(OBFUSCATE("pthread created"));
    do {
        sleep(1);
    } while (!isLibraryLoaded(targetLibName));
    
        LOGI(OBFUSCATE("%s has been loaded"), (const char *) targetLibName);

PATCH_LIB("libil2cpp.so", "0x73DDA0", "00 00 A0 E3 1E FF 2F E1");//true
PATCH_LIB("libil2cpp.so", "0x8A9D7C", "36 07 47 E3 1E FF 2F E1");//false
//AddCoin = (void(*)(void *,int))getAbsoluteAddress(targetLibName, 0x8847BC);

    LOGI(OBFUSCATE("Done"));
    
    return NULL;
}
 
    
void Init_Thread() {
    while (!m_Il2Cpp) {
        m_Il2Cpp = Tools::GetBaseAddress(m_IL2CPPLIB);
        sleep(5);
    }
        
    LOGI("libil2cpp.so: %p", m_Il2Cpp);

    Il2CppAttach();

    sleep(10);

Tools::Hook((void *) (uintptr_t)Il2CppGetMethodOffset("Assembly-CSharp.dll","SYBO.RunnerCore.Character","CharacterMotorAbilities" , "get_MinSpeed"), (void *) getMinSpeed, (void **) &old_MinSpeed);
Tools::Hook((void *) (uintptr_t)Il2CppGetMethodOffset("Assembly-CSharp.dll","SYBO.RunnerCore.Character","CharacterMotorAbilities" , "get_MaxSpeed"), (void *) getMaxSpeed, (void **) &old_MaxSpeed);

Tools::Hook((void *) (uintptr_t)Il2CppGetMethodOffset("Assembly-CSharp.dll","SYBO.RunnerCore.Character","CharacterMotorAbilities" , "get_JumpHeight"), (void *) jump, (void **) &old_jump);
Tools::Hook((void *) (uintptr_t)Il2CppGetMethodOffset("Assembly-CSharp.dll","SYBO.RunnerCore.Character","CharacterMotorAbilities" , "get_AirJumpHeight"), (void *) jump1, (void **) &old_jump1);

Tools::Hook((void *) (uintptr_t)Il2CppGetMethodOffset("Assembly-CSharp.dll","SYBO.RunnerCore.Character","CharacterMotorAbilities" , "get_LaneChangeDuration"), (void *) Instan, (void **) &old_Instan);

Tools::Hook((void *) (uintptr_t)Il2CppGetMethodOffset("Assembly-CSharp.dll","SYBO.Subway.Meta","WalletModel" , "GetCurrency"), (void *) Coin, (void **) &old_Coin);

Tools::Hook((void *) (uintptr_t)Il2CppGetMethodOffset("Assembly-CSharp.dll","SYBO.Subway.Meta","Currency" , "get_IsIAP"), (void *) FreeBuy, (void **) &old_FreeBuy);

Tools::Hook((void *) (uintptr_t)Il2CppGetMethodOffset("Assembly-CSharp.dll","SYBO.Subway.Migration","KilooCloudSave" , "get_HasDoneIAPPurchase"), (void *) FreeBuy1, (void **) &old_FreeBuy1);

Tools::Hook((void *) (uintptr_t)Il2CppGetMethodOffset("Assembly-CSharp.dll","SYBO.Subway","EndRunSequence" , "get_Score"), (void *) Score, (void **) &old_Score);

Tools::Hook((void *) (uintptr_t)Il2CppGetMethodOffset("Assembly-CSharp.dll","SYBO.Subway","EndRunSequence" , "get_OwnsCoinDoubler"), (void *) DCoin, (void **) &old_DCoin);

Tools::Hook((void *) (uintptr_t)Il2CppGetMethodOffset("Assembly-CSharp.dll","SYBO.Subway","EndRunSequence" , "get_HasGivenBonusCoins"), (void *) BCoin, (void **) &old_BCoin);

Tools::Hook((void *) (uintptr_t)Il2CppGetMethodOffset("Assembly-CSharp.dll","SYBO.Subway.Meta","Achievement" , "get_IsTierCompleted"), (void *) Activement, (void **) &old_Activement);

Tools::Hook((void *) (uintptr_t)Il2CppGetMethodOffset("Assembly-CSharp.dll","SYBO.Subway","CharacterStumble" , "IsAutoReviveEnabled"), (void *) AutoRevive, (void **) &old_AutoRevive);

Tools::Hook((void *) (uintptr_t)Il2CppGetMethodOffset("Assembly-CSharp.dll","SYBO.Subway.Systems","MainReviveSystem" , "get_ReviveCost"), (void *) AutoRevive1, (void **) &old_AutoRevive1);

Tools::Hook((void *) (uintptr_t)Il2CppGetMethodOffset("Assembly-CSharp.dll","SYBO.Subway.Systems","MainReviveSystem" , "get_HasMilestoneHint"), (void *) AutoRevive2, (void **) &old_AutoRevive2);

Tools::Hook((void *) (uintptr_t)Il2CppGetMethodOffset("Assembly-CSharp.dll","SYBO.Subway","CharacterStumble" , "Kill"), (void *) GodMode, (void **) &old_GodMode);

Tools::Hook((void *) (uintptr_t)Il2CppGetMethodOffset("Assembly-CSharp.dll","SYBO.Subway","CharacterStumble" , "Stumble"), (void *) GodMode1, (void **) &old_GodMode1);

Tools::Hook((void *) (uintptr_t)Il2CppGetMethodOffset("Assembly-CSharp.dll","SYBO.RunnerCore.Character","CharacterMotor" , "get_HasMultiJumpsRemaining"), (void *) MultiJump, (void **) &old_MultiJump);

Tools::Hook((void *) (uintptr_t)Il2CppGetMethodOffset("Assembly-CSharp.dll","SYBO.RunnerCore.Character","CharacterMotor" , "get_CanJump"), (void *) MultiJump1, (void **) &old_MultiJump1);

Tools::Hook((void *) (uintptr_t)Il2CppGetMethodOffset("Assembly-CSharp.dll","SYBO.RunnerCore.Character","CharacterMotor" , "CheckFrontalImpact"), (void *) GodMode2, (void **) &old_GodMode2);

Tools::Hook((void *) (uintptr_t)Il2CppGetMethodOffset("Assembly-CSharp.dll","SYBO.RunnerCore.Character","CharacterMotor" , "CheckSideImpact"), (void *) old_GodMode3, (void **) &old_GodMode3);

Tools::Hook((void *) (uintptr_t)Il2CppGetMethodOffset("Assembly-CSharp.dll","SYBO.RunnerCore.Character","CharacterMotor" , "ApplyGravity"), (void *) gravi, (void **) &old_gravi);

Tools::Hook((void *) (uintptr_t)Il2CppGetMethodOffset("Assembly-CSharp.dll","SYBO.Subway","ScoreMultiplierManager" , "get_BaseMultiplierSum"), (void *) MultiScore, (void **) &old_MultiScore);

Tools::Hook((void *) (uintptr_t)Il2CppGetMethodOffset("Assembly-CSharp.dll","SYBO.Subway","CameraGroundedModifier" , "Apply"), (void *) CameraF, (void **) &old_CameraF);

Tools::Hook((void *) (uintptr_t)Il2CppGetMethodOffset("Assembly-CSharp.dll","SYBO.Subway","CameraOffsetModifier" , "Apply"), (void *) CameraS, (void **) &old_CameraS);

Tools::Hook((void *) (uintptr_t)Il2CppGetMethodOffset("Assembly-CSharp.dll","SYBO.Subway","MovingTrain" , "Displace"), (void *) StopTrain, (void **) &old_StopTrain);

//Tools::Hook((void *) (uintptr_t)Il2CppGetMethodOffset("Assembly-CSharp.dll","SYBO.Subway","RunSessionData" , "SetEndGameScore"), (void *) MoneyUpdate, (void **) &old_MoneyUpdate);

}


jobjectArray GetFeatureList(JNIEnv *env, jobject context) {
    jobjectArray ret;

    const char *features[] = {
            OBFUSCATE("Collapse_MAIN MENU"),
            OBFUSCATE("1_CollapseAdd_Toggle_UNLIMITED ALL"),
         //   OBFUSCATE("15_CollapseAdd_Toggle_Add Coin"),
            OBFUSCATE("2_CollapseAdd_Toggle_FREE PURCHASE"),
            OBFUSCATE("3_CollapseAdd_Toggle_UNLOCK ALL ACTIVEMENT"),
            
            OBFUSCATE("Collapse_MENU INGAME"),
            OBFUSCATE("4_CollapseAdd_SeekBar_MOVE SPEED_0_2000"),
            OBFUSCATE("5_CollapseAdd_SeekBar_JUMP HEIGHT_0_100"),
            OBFUSCATE("6_CollapseAdd_Toggle_INSTAN GANTI JALUR"),
            OBFUSCATE("7_CollapseAdd_Toggle_NO GRAVITASI"),
            OBFUSCATE("8_CollapseAdd_Toggle_DOUBLE COIN"),
            OBFUSCATE("9_CollapseAdd_Toggle_BONUS COIN"),
            OBFUSCATE("10_CollapseAdd_Toggle_MULTI SCORE"),
            OBFUSCATE("11_CollapseAdd_Toggle_MULTI JUMP"),
            OBFUSCATE("12_CollapseAdd_Toggle_GOD MODE"),
            OBFUSCATE("13_CollapseAdd_Toggle_NO GRAVITASY"),
            OBFUSCATE("14_CollapseAdd_Toggle_NO MOVING TRAIN"),
            
            OBFUSCATE("Collapse_MENU CAMERA"),
            OBFUSCATE("17_CollapseAdd_Toggle_FOLLOW"),
            OBFUSCATE("18_CollapseAdd_Toggle_STOP"),
            
            OBFUSCATE("RichTextView_MOD BY NEXTJEK"
                      "<br/><font color='green'><b>PROJECT AUTO UPDATE</b></font>"
                      "<br/><font color='red'>SUPPORT ALL GAME</font>"
                      "<br/><font color='yellow'><big>FREE FOR ALL</big></font>"
                      "<br/><font color='red'>SUBWAY SURF 3.9.0</font>"),
    };

    //Now you dont have to manually update the number everytime;
    int Total_Feature = (sizeof features / sizeof features[0]);
    ret = (jobjectArray)
            env->NewObjectArray(Total_Feature, env->FindClass(OBFUSCATE("java/lang/String")),
                                env->NewStringUTF(""));

    for (int i = 0; i < Total_Feature; i++)
        env->SetObjectArrayElement(ret, i, env->NewStringUTF(features[i]));

    return (ret);
}

void Changes(JNIEnv *env, jclass clazz, jobject obj,
                                        jint featNum, jstring featName, jint value,
                                        jboolean boolean, jstring str) {

    LOGD(OBFUSCATE("Feature name: %d - %s | Value: = %d | Bool: = %d | Text: = %s"), featNum,
         env->GetStringUTFChars(featName, 0), value,
         boolean, str != NULL ? env->GetStringUTFChars(str, 0) : "");

    //BE CAREFUL NOT TO ACCIDENTLY REMOVE break;

    switch (featNum) {
    case 1:
    isCoin = boolean;
	break;
    case 2:
    isFreeBuy = boolean;
    isFreeBuy1 = boolean;
    break;
    case 3:
    isActivement = boolean;
    break;
    case 4:
    IsMinSpeed = value;
    isMaxSpedd = value;
    break;
    case 5:
    IsHightjump = value;
	SliderValue = value;
    break;
    case 6:
    isInstan = boolean;
    break;
    case 7:
    gravitasi = boolean;
    break;
    case 8:
    isDCoin = boolean;
    break;
    case 9:
    isBCoin = boolean;
    break;
    case 10:
    isMultiScore = boolean;
    break;
    case 11:
    isMultiJump = boolean;
    isMultiJump1 = boolean;
    break;
    case 12:
    isGodMode = boolean;
    isGodMode1 = boolean;
    isGodMode2 = boolean;
    isGodMode3 = boolean;
    isAutoRevive = boolean;
    isAutoRevive1 = boolean;
    break;
    case 13:
    gravitasi = boolean;
    break;
    case 14:
    isStopTrain = boolean;
    break;
    case 15:
  //  isAddCoin = boolean;
    break;
    case 16:
    
    break;
    case 17:
    isCameraF = boolean;
    break;
    case 18:
    isCameraS = boolean;
    break;
    
    
    
    }
}

__attribute__((constructor))
void lib_main() {
    pthread_t ptid;
    pthread_create(&ptid, NULL, hack_thread, NULL);
    std::thread(Init_Thread).detach();
}

int RegisterMenu(JNIEnv *env) {
    JNINativeMethod methods[] = {
            {OBFUSCATE("Icon"), OBFUSCATE("()Ljava/lang/String;"), reinterpret_cast<void *>(Icon)},
            {OBFUSCATE("IconWebViewData"),  OBFUSCATE("()Ljava/lang/String;"), reinterpret_cast<void *>(IconWebViewData)},
            {OBFUSCATE("IsGameLibLoaded"),  OBFUSCATE("()Z"), reinterpret_cast<void *>(isGameLibLoaded)},
            {OBFUSCATE("Init"),  OBFUSCATE("(Landroid/content/Context;Landroid/widget/TextView;Landroid/widget/TextView;)V"), reinterpret_cast<void *>(Init)},
            {OBFUSCATE("SettingsList"),  OBFUSCATE("()[Ljava/lang/String;"), reinterpret_cast<void *>(SettingsList)},
            {OBFUSCATE("GetFeatureList"),  OBFUSCATE("()[Ljava/lang/String;"), reinterpret_cast<void *>(GetFeatureList)},
    };

    jclass clazz = env->FindClass(OBFUSCATE("com/android/support/Menu"));
    if (!clazz)
        return JNI_ERR;
    if (env->RegisterNatives(clazz, methods, sizeof(methods) / sizeof(methods[0])) != 0)
        return JNI_ERR;
    return JNI_OK;
}

int RegisterPreferences(JNIEnv *env) {
    JNINativeMethod methods[] = {
            {OBFUSCATE("Changes"), OBFUSCATE("(Landroid/content/Context;ILjava/lang/String;IZLjava/lang/String;)V"), reinterpret_cast<void *>(Changes)},
    };
    jclass clazz = env->FindClass(OBFUSCATE("com/android/support/Preferences"));
    if (!clazz)
        return JNI_ERR;
    if (env->RegisterNatives(clazz, methods, sizeof(methods) / sizeof(methods[0])) != 0)
        return JNI_ERR;
    return JNI_OK;
}

int RegisterMain(JNIEnv *env) {
    JNINativeMethod methods[] = {
            {OBFUSCATE("CheckOverlayPermission"), OBFUSCATE("(Landroid/content/Context;)V"), reinterpret_cast<void *>(CheckOverlayPermission)},
    };
    jclass clazz = env->FindClass(OBFUSCATE("com/android/support/Main"));
    if (!clazz)
        return JNI_ERR;
    if (env->RegisterNatives(clazz, methods, sizeof(methods) / sizeof(methods[0])) != 0)
        return JNI_ERR;

    return JNI_OK;
}

extern "C"
JNIEXPORT jint JNICALL
JNI_OnLoad(JavaVM *vm, void *reserved) {
    JNIEnv *env;
    vm->GetEnv((void **) &env, JNI_VERSION_1_6);
    if (RegisterMenu(env) != 0)
        return JNI_ERR;
    if (RegisterPreferences(env) != 0)
        return JNI_ERR;
    if (RegisterMain(env) != 0)
        return JNI_ERR;
    return JNI_VERSION_1_6;
}
