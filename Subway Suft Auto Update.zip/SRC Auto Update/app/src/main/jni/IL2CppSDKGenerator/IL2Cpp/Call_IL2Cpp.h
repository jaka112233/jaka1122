#pragma once

#include "Il2Cpp.h"
#include "plthook.h"
#include "Tools.h"
